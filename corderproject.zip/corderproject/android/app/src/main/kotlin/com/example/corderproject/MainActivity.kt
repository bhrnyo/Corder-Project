package com.example.corderproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
